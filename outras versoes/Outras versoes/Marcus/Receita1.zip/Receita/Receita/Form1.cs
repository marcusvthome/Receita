﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Receita
{
    public partial class FormPrincipal : FormBase
    {
        private List<Receita> dados = new List<Receita>();
        private List<Receita> listaDados;

        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void bntInserir_Click(object sender, EventArgs e)
        {
            FormInsercao f = new FormInsercao();
            f.Show();
            
            if (f.ReceitaInserida != null)
            {
                dados.Add(f.ReceitaInserida);
                listaDados = dados;
                dataGridView1.DataSource = listaDados;
                MessageBox.Show("Usuário inserido com sucesso", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }    
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
        }
    }
}
