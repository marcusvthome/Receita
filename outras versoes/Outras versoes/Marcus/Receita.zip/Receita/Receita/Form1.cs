﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Receita
{
    public partial class FormPrincipal : FormBase
    {
        private List<Receita> dados = new List<Receita>();

        public FormPrincipal()
        {
            InitializeComponent();
            
        }

        private void bntInserir_Click(object sender, EventArgs e)
        {
            FormInsercao f = new FormInsercao();
            f.ShowDialog();
            
            if (f.ReceitaInserida != null)
            {
                dados.Add(f.ReceitaInserida);
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = dados;
                MessageBox.Show("Usuário inserido com sucesso", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }
        private void FormPrincipal_Load(object sender, EventArgs e)
        {
           // comboBox1.SelectedIndex = 0;
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*switch (comboBox1.SelectedIndex)
            {
                case 0:
                    dataGridView1.DataSource = dados;
                    break;
                case 1:

                    List<Receita> novalista = new List<Receita>();
                    foreach (Receita r in dados)
                    {
                        if (r.Titulo == "Doce")
                            novalista.Add(r);
                    }
                    dataGridView1.DataSource = novalista;
                    break;

                case 2:

                    dataGridView1.DataSource = dados.FindAll(x => x.Titulo == "Salgado");
                    break;

            }*/
        }
    }
}
