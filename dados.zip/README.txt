Coloque a pasta dados no disco local C

Referências das receitas

https://www.tudogostoso.com.br/receita/13205-fondue-de-chocolate.html
https://www.tudogostoso.com.br/receita/12216-nachos-mexicanos.html
https://www.tudogostoso.com.br/receita/124626-caldo-de-mandioca.html
https://www.tudogostoso.com.br/receita/42591-canja-de-galinha-rapida.html
https://www.tudogostoso.com.br/receita/1270-torta-holandesa.html
https://www.tudogostoso.com.br/receita/143574-cupcake-de-chocolate.html
https://www.tudogostoso.com.br/receita/105067-pao-recheado.html
https://www.tudogostoso.com.br/receita/302-pizza-de-pao-de-forma.html
https://www.tudogostoso.com.br/receita/82681-massa-de-panqueca.html